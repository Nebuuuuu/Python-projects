from gui import *

def testcheck(couleur, plateau, listeblanc, listenoir, coord = None):
    if couleur == 'blanc':
        if coord == None:
            for piece in listeblanc:
                if type(piece) == Roi:
                    coordroi = piece.coord
        else:
            coordroi= coord

        for piece in listenoir:
            if type(piece) != Roi:
                for move in piece.possiblemove(plateau, listeblanc, listenoir):
                    if move == coordroi:
                        return True
        return False

    else:
        if coord == None:
            for piece in listenoir:
                if type(piece) == Roi:
                    coordroi = piece.coord
        else:
            coordroi = coord

        for piece in listeblanc:
            if type(piece) != Roi:
                for move in piece.possiblemove(plateau, listeblanc, listenoir):
                    if move == coordroi:
                        return True
        return False


class Piece:
    def __init__(self,coord,couleur):
        self.coord = coord
        self.couleur = couleur


class Pion(Piece):
    def __init__(self,coord,couleur):
        super().__init__(coord,couleur)
        if self.couleur == "blanc":
            self.image = pion_w
        else:
            self.image = pion_b

    def possiblemove(self,plateau, listeblanc, listenoir):
        case = []
        base = self.coord


        if self.couleur == "blanc":
            #Premier coup, peut avancer de 2 cases
            if base[0] == 1:
                if plateau[2][base[1]] == [] and plateau[3][base[1]]== []:
                    case.append([3,base[1]])

            #Avancer tout court
            if base[0] != 7:
                if plateau[base[0]+1][base[1]] == []:
                    case.append([base[0]+1,base[1]])

            #Diagonal gauche
                if base[1] != 0:
                    if plateau[base[0]+1][base[1]-1] != [] and plateau[base[0]+1][base[1]-1].couleur == "noir":
                        case.append([base[0]+1,base[1]-1])
                #Diagonal droite
                if base[1] != 7:
                    if plateau[base[0]+1][base[1]+1] != [] and plateau[base[0]+1][base[1]+1].couleur == "noir":
                        case.append([base[0]+1,base[1]+1])


        else:
            #Premier coup, peut avancer de 2 cases
            if base[0] == 6:
                if plateau[5][base[1]] == [] and plateau[4][base[1]]== []:
                    case.append([4,base[1]])

            #Avancer tout court
            if base[0] != 0:
                if plateau[base[0]-1][base[1]] == []:
                    case.append([base[0]-1,base[1]])

            #Diagonal gauche
                if base[1] != 0:
                    if plateau[base[0]-1][base[1]-1] != [] and plateau[base[0]-1][base[1]-1].couleur == "blanc":
                        case.append([base[0]-1,base[1]-1])
                #Diagonal droite
                if base[1] != 7:
                    if plateau[base[0]-1][base[1]+1] != [] and plateau[base[0]-1][base[1]+1].couleur == "blanc":
                        case.append([base[0]-1,base[1]+1])

        return case


class Tour(Piece):
    def __init__(self,coord,couleur):
        super().__init__(coord,couleur)
        self.roquepossible = True
        if self.couleur == "blanc":
            self.image = tour_w
        else:
            self.image = tour_b

    def possiblemove(self, plateau, listeblanc, listenoir):
        case = []
        base = self.coord

        #Vers le haut
        for i in range(base[0]+1,8):
            if plateau[i][base[1]] != [] :
                if plateau[i][base[1]].couleur != self.couleur:
                    case.append([i,base[1]])
                break
            else:
                case.append([i,base[1]])

        #Vers le bas
        for i in range(base[0]-1,-1,-1):
            if plateau[i][base[1]] != []:
                if plateau[i][base[1]].couleur != self.couleur:
                    case.append([i,base[1]])
                break
            else:
                case.append([i,base[1]])

        #Vers la droite
        for i in range(base[1]+1,8):
            if plateau[base[0]][i] != []:
                if plateau[base[0]][i].couleur != self.couleur:
                    case.append([base[0],i])
                break
            else:
                case.append([base[0],i])

        #Vers la gauche
        for i in range(base[1]-1,-1,-1):
            if plateau[base[0]][i] != []:
                if plateau[base[0]][i].couleur != self.couleur:
                    case.append([base[0],i])
                break
            else:
                case.append([base[0],i])

        return case

class Cavalier(Piece):
    def __init__(self,coord,couleur):
        super().__init__(coord,couleur)
        if self.couleur == "blanc":
            self.image = cavalier_w
        else:
            self.image = cavalier_b

    def possiblemove(self, plateau, listeblanc, listenoir):
        case = []
        base = self.coord

        #Haut
        if base[0] < 6:
            #Gauche
            if base[1] != 0:
                if plateau[base[0]+2][base[1]-1] == [] or plateau[base[0]+2][base[1]-1].couleur != self.couleur:
                    case.append([base[0]+2,base[1]-1])
            #Droite
            if base[1] != 7:
                if plateau[base[0]+2][base[1]+1] == [] or plateau[base[0]+2][base[1]+1].couleur != self.couleur:
                    case.append([base[0]+2,base[1]+1])

        #Bas
        if base[0] > 1:
            #Gauche
            if base[1] != 0:
                if plateau[base[0]-2][base[1]-1] == [] or plateau[base[0]-2][base[1]-1].couleur != self.couleur:
                    case.append([base[0]-2,base[1]-1])
            #Droite
            if base[1] != 7:
                if plateau[base[0]-2][base[1]+1] == [] or plateau[base[0]-2][base[1]+1].couleur != self.couleur:
                    case.append([base[0]-2,base[1]+1])

        #Droite
        if base[1] < 6:
            #Bas
            if base[0] != 0:
                if plateau[base[0]-1][base[1]+2] == [] or plateau[base[0]-1][base[1]+2].couleur != self.couleur:
                    case.append([base[0]-1,base[1]+2])
            #Haut
            if base[0] != 7:
                if plateau[base[0]+1][base[1]+2] == [] or plateau[base[0]+1][base[1]+2].couleur != self.couleur:
                    case.append([base[0]+1,base[1]+2])

        #Gauche
        if base[1] > 1:
            #Bas
            if base[0] != 0:
                if plateau[base[0]-1][base[1]-2] == [] or plateau[base[0]-1][base[1]-2].couleur != self.couleur:
                    case.append([base[0]-1,base[1]-2])
            #Haut
            if base[0] != 7:
                if plateau[base[0]+1][base[1]-2] == [] or plateau[base[0]+1][base[1]-2].couleur != self.couleur:
                    case.append([base[0]+1,base[1]-2])

        return case





class Fou(Piece):
    def __init__(self,coord,couleur):
        super().__init__(coord,couleur)
        if self.couleur == "blanc":
            self.image = fou_w
        else:
            self.image = fou_b

    def possiblemove(self, plateau, listeblanc, listenoir):
        case = []
        base = self.coord

        #Définie la plus grand longueur
        if base[0]>=base[1]:
            main = 0
            other = 1
        else:
            main = 1
            other = 0

        #Haut droite
        i=1
        while base[main]+i <= 7:
            # print('a')
            if plateau[base[0]+i][base[1]+i] != []:
                if plateau[base[0]+i][base[1]+i].couleur != self.couleur:
                    case.append([base[0]+i,base[1]+i])
                break
            else:
                case.append([base[0]+i,base[1]+i])
            i+=1

        #Bas gauche
        j=1
        while base[other]-j >= 0:

            if plateau[base[0]-j][base[1]-j] != []:
                if plateau[base[0]-j][base[1]-j].couleur != self.couleur:
                    case.append([base[0]-j,base[1]-j])
                break
            else:
                case.append([base[0]-j,base[1]-j])
            j+=1

        #Bas droite
        i=1
        while base[0]-i >= 0 and base[1]+i <= 7:
            # print('a')
            if plateau[base[0]-i][base[1]+i] != []:
                if plateau[base[0]-i][base[1]+i].couleur != self.couleur:
                    case.append([base[0]-i,base[1]+i])
                break
            else:
                case.append([base[0]-i,base[1]+i])
            i+=1

        #Haut gauche
        j=1
        while base[0]+j <= 7 and base[1]-j >= 0:
            # print('a')
            if plateau[base[0]+j][base[1]-j] != []:
                if plateau[base[0]+j][base[1]-j].couleur != self.couleur:
                    case.append([base[0]+j,base[1]-j])
                break
            else:
                case.append([base[0]+j,base[1]-j])
            j+=1

        return case

class Dame(Piece):
    def __init__(self,coord,couleur):
        super().__init__(coord,couleur)
        if self.couleur == "blanc":
            self.image = dame_w
        else:
            self.image = dame_b

    def possiblemove(self, plateau, listeblanc, listenoir):
        case = []
        base = self.coord

        #Définie la plus grand longueur
        if base[0]>=base[1]:
            main = 0
            other = 1
        else:
            main = 1
            other = 0

        #Haut droite
        i=1
        while base[main]+i <= 7:
            # print('a')
            if plateau[base[0]+i][base[1]+i] != []:
                if plateau[base[0]+i][base[1]+i].couleur != self.couleur:
                    case.append([base[0]+i,base[1]+i])
                break
            else:
                case.append([base[0]+i,base[1]+i])
            i+=1

        #Bas gauche
        j=1
        while base[other]-j >= 0:

            if plateau[base[0]-j][base[1]-j] != []:
                if plateau[base[0]-j][base[1]-j].couleur != self.couleur:
                    case.append([base[0]-j,base[1]-j])
                break
            else:
                case.append([base[0]-j,base[1]-j])
            j+=1

        #Bas droite
        i=1
        while base[0]-i >= 0 and base[1]+i <= 7:
            #print(base[0]-i,base[1]+i)
            if plateau[base[0]-i][base[1]+i] != []:
                if plateau[base[0]-i][base[1]+i].couleur != self.couleur:
                    case.append([base[0]-i,base[1]+i])
                break
            else:
                case.append([base[0]-i,base[1]+i])
            i+=1

        #Haut gauche
        j=1
        while base[0]+j <= 7 and base[1]-j >= 0:
            # print('a')
            if plateau[base[0]+j][base[1]-j] != []:
                if plateau[base[0]+j][base[1]-j].couleur != self.couleur:
                    case.append([base[0]+j,base[1]-j])
                break
            else:
                case.append([base[0]+j,base[1]-j])
            j+=1

        #Vers le haut
        for i in range(base[0]+1,8):
            if plateau[i][base[1]] != [] :
                if plateau[i][base[1]].couleur != self.couleur:
                    case.append([i,base[1]])
                break
            else:
                case.append([i,base[1]])

        #Vers le bas
        for i in range(base[0]-1,-1,-1):
            if plateau[i][base[1]] != []:
                if plateau[i][base[1]].couleur != self.couleur:
                    case.append([i,base[1]])
                break
            else:
                case.append([i,base[1]])

        #Vers la droite
        for i in range(base[1]+1,8):
            if plateau[base[0]][i] != []:
                if plateau[base[0]][i].couleur != self.couleur:
                    case.append([base[0],i])
                break
            else:
                case.append([base[0],i])

        #Vers la gauche
        for i in range(base[1]-1,-1,-1):
            if plateau[base[0]][i] != []:
                if plateau[base[0]][i].couleur != self.couleur:
                    case.append([base[0],i])
                break
            else:
                case.append([base[0],i])

        return case

class Roi(Piece):
    def __init__(self,coord,couleur):
        super().__init__(coord,couleur)
        self.roquepossible = True
        if self.couleur == "blanc":
            self.image = roi_w
        else:
            self.image = roi_b

    def possiblemove(self, plateau, listeblanc, listenoir):
        case = []
        base = self.coord

        for k in range(-1,2,2):
            try:
                if 0 <= base[0]+k <=7:
                    if plateau[base[0]+k][base[1]] == []:
                        case.append([base[0]+k,base[1]])
                    elif plateau[base[0]+k][base[1]].couleur != self.couleur:
                        case.append([base[0]+k,base[1]])
            except: pass

        for j in range(-1,2,2):
            for i in range(-1,2):
                try:
                    if base[0]+i > -1 and base[1]+j > -1:
                        if plateau[base[0]+i][base[1]+j] == []:
                            case.append([base[0]+i,base[1]+j])
                        elif plateau[base[0]+i][base[1]+j].couleur != self.couleur:
                            case.append([base[0]+i,base[1]+j])
                except:
                    pass

        if self.roquepossible:
            #Tour de gauche
            if type(plateau[base[0]][0]) == Tour:
                if plateau[base[0]][0].roquepossible:
                    uwu = True
                    for i in range(3):
                        if plateau[base[0]][1+i] != [] or testcheck(self.couleur, plateau, listeblanc, listenoir, coord = [base[0],1+i]):
                            uwu = False
                    if uwu:
                        case.append([base[0],2])

            #Tour de droite
            if type(plateau[base[0]][7]) == Tour:
                if plateau[base[0]][7].roquepossible:
                    uwu = True
                    for i in range(2):
                        if plateau[base[0]][5+i] != [] or testcheck(self.couleur, plateau, listeblanc, listenoir, coord = [base[0],5+i]):
                            uwu = False
                    if uwu:
                        case.append([base[0],6])

        return case






# plato = [[[] for i in range(8)]for j in range(8)]
#
# t = Roi([5,6],"Noir")
# # a = Pion([4,3],"Blanc")
#
# plato[5][6] = "O"
# # plato[4][3] = a
#
#
#
# for i in range(len(plato)):
#     print(8-i,plato[-1-i])
#
#
#
# for i in t.possiblemove(plato):
#     plato[i[0]][i[1]] = "X"
#
#
# print("")
#
# for i in range(len(plato)):
#     print(8-i,plato[-1-i])
