import pygame
from pygame.locals import *
import os



SIZE = (900,900)
DEFAULT_PIECE_SIZE = (90,90)
VERT_TRANS = (118,150,86)
BLANC_TRANS = (238,238,210)


pygame.init()
#Crée la fenetre
FENETRE = pygame.display.set_mode(SIZE)
pygame.display.set_caption("Echec 2 joueurs")


#Initialise les images
fou_b = pygame.image.load(os.getcwd()+"\\data\\fou_noir.png").convert()
fou_b.set_colorkey((255,255,255))
fou_b = pygame.transform.scale(fou_b, DEFAULT_PIECE_SIZE)
cavalier_b = pygame.image.load(os.getcwd()+"\\data\\cavalier_noir.png").convert()
cavalier_b.set_colorkey(VERT_TRANS)
cavalier_b = pygame.transform.scale(cavalier_b, DEFAULT_PIECE_SIZE)
dame_b = pygame.image.load(os.getcwd()+"\\data\\dame_noire.png").convert()
dame_b.set_colorkey(VERT_TRANS)
dame_b = pygame.transform.scale(dame_b, DEFAULT_PIECE_SIZE)
roi_b = pygame.image.load(os.getcwd()+"\\data\\roi_noir.png").convert()
roi_b.set_colorkey(BLANC_TRANS)
roi_b = pygame.transform.scale(roi_b, DEFAULT_PIECE_SIZE)
pion_b = pygame.image.load(os.getcwd()+"\\data\\pion_noir.png").convert()
pion_b.set_colorkey(VERT_TRANS)
pion_b = pygame.transform.scale(pion_b, DEFAULT_PIECE_SIZE)
tour_b = pygame.image.load(os.getcwd()+"\\data\\tour_noire.png").convert()
tour_b.set_colorkey(BLANC_TRANS)
tour_b = pygame.transform.scale(tour_b, DEFAULT_PIECE_SIZE)
fou_w = pygame.image.load(os.getcwd()+"\\data\\fou_blanc.png").convert()
fou_w.set_colorkey(VERT_TRANS)
fou_w = pygame.transform.scale(fou_w, DEFAULT_PIECE_SIZE)
cavalier_w = pygame.image.load(os.getcwd()+"\\data\\cavalier_blanc.png").convert()
cavalier_w.set_colorkey(BLANC_TRANS)
cavalier_w = pygame.transform.scale(cavalier_w, DEFAULT_PIECE_SIZE)
dame_w = pygame.image.load(os.getcwd()+"\\data\\dame_blanche.png").convert()
dame_w.set_colorkey(BLANC_TRANS)
dame_w = pygame.transform.scale(dame_w, DEFAULT_PIECE_SIZE)
roi_w = pygame.image.load(os.getcwd()+"\\data\\roi_blanc.png").convert()
roi_w.set_colorkey(VERT_TRANS)
roi_w = pygame.transform.scale(roi_w, DEFAULT_PIECE_SIZE)
pion_w = pygame.image.load(os.getcwd()+"\\data\\pion_blanc.png").convert()
pion_w.set_colorkey(BLANC_TRANS)
pion_w = pygame.transform.scale(pion_w, DEFAULT_PIECE_SIZE)
tour_w = pygame.image.load(os.getcwd()+"\\data\\tour_blanche.png").convert()
tour_w.set_colorkey(VERT_TRANS)
tour_w = pygame.transform.scale(tour_w, DEFAULT_PIECE_SIZE)

promote_w = pygame.image.load(os.getcwd()+"\\data\\promote_blanc.png").convert()
promote_b = pygame.image.load(os.getcwd()+"\\data\\promote_noir.png").convert()


echiquier = pygame.image.load(os.getcwd()+"\\data\\plateau.png").convert()


