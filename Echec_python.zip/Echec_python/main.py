from pieces import *
from gui import *
import pygame
from pygame.locals import *
from time import sleep

def format(coord):
    coord = [coord[1]*90+90, 720-coord[0]*90]
    return coord

def unformat(coord):
    coord = [((coord[1]-90)//90-7)*-1,(coord[0]-720)//90+7]
    return coord

def draw_circle_alpha(surface, color, center, radius):
    target_rect = pygame.Rect(center, (0, 0)).inflate((radius * 2, radius * 2))
    shape_surf = pygame.Surface(target_rect.size, pygame.SRCALPHA)
    pygame.draw.circle(shape_surf, color, (radius, radius), radius)
    surface.blit(shape_surf, target_rect)




    
def deplacement(pos,plateau, select, moves, listenoir, listeblanc,joueur):
    test = False
    
    #Si move selectionné
    if select != None and select.couleur == joueur:

        if pos in moves:
            test = True
        if test:
        # Supprime la pièce (s'il y en a une) a la case d'arrivée 
            if plateau[pos[0]][pos[1]] != []:
                try:
                    listeblanc.remove(plateau[pos[0]][pos[1]])
                except:
                    listenoir.remove(plateau[pos[0]][pos[1]])
                    
            plateau[pos[0]][pos[1]] = select

            #Déroque
            if type(select) == Tour or type(select) == Roi:

                #Deplacement tour lors du roque
                if type(select) == Roi and select.roquepossible:
                    if not testcheck(joueur,plateau, listeblanc, listenoir):
                        
                        #Grand roque
                        if pos[1] == 2 and pos[0] == 0:
                            plateau[0][3] = plateau[0][0]
                            plateau[0][3].coord = [0, 3]
                            plateau[0][0] = []
                        elif pos[1] == 2 and pos[0] == 7:
                            plateau[7][3] = plateau[7][0]
                            plateau[7][3].coord = [7, 3]
                            plateau[7][0] = []

                        #Petit roque
                        elif pos[1] == 6 and pos[0] == 0:
                            plateau[0][5] = plateau[0][7]
                            plateau[0][5].coord = [0, 5]
                            plateau[0][7] = []
                        elif pos[1] == 6 and pos[0] == 7:
                            plateau[7][5] = plateau[7][7]
                            plateau[7][5].coord = [7, 5]
                            plateau[7][7] = []

                select.roquepossible = False
        

            plateau[select.coord[0]][select.coord[1]] = []
            select.coord = pos
            test = True
        select = None
        moves = []
            


    #Affiche move possible
    else:
        try:
            
            for move in plateau[pos[0]][pos[1]].possiblemove(plateau, listeblanc, listenoir):
                testlisteblanc, testlistenoir = [],[]
                testplateau = [[[] for i in range(8)]for j in range(8)]
                for i in range(8):
                    for j in range(8):
                        if plateau[i][j] != []:
                            testpiece = Piece(plateau[i][j].coord,plateau[i][j].couleur)
                            testplateau[i][j] = testpiece
                            
                
                for piece in listeblanc:
                    if piece.coord != move :
                        testlisteblanc.append(type(piece)(piece.coord,piece.couleur))
                for piece in listenoir:
                    if piece.coord != move :
                        testlistenoir.append(type(piece)(piece.coord,piece.couleur))
            
                    
                testplateau[move[0]][move[1]] = testplateau[pos[0]][pos[1]]
                testplateau[move[0]][move[1]].coord = move
                testplateau[pos[0]][pos[1]] = []
                
                if joueur == "blanc":
                    for piece in testlisteblanc:
                        if type(plateau[pos[0]][pos[1]]) == Roi:
                            piece.coord = move
                if joueur == "noir":
                    for piece in testlistenoir:
                        if type(plateau[pos[0]][pos[1]]) == Roi:
                            piece.coord = move
                            
                if not testcheck(joueur, testplateau, testlisteblanc, testlistenoir):
                    moves.append(move)
                    
    
            # moves = plateau[pos[0]][pos[1]].possiblemove(plateau, listeblanc, listenoir)
    
            if moves != []:
                select = plateau[pos[0]][pos[1]]
                print(type(select),moves,"possible")
            else:print("Aucun move légal possible")

        except:
            select = None
            moves = []
            print('case vide')
            
    return plateau, select, moves, listenoir, listeblanc, test
            
def affichemove(moves):
    for draw in moves:
        draw = format(draw)
        try:
            draw_circle_alpha(FENETRE,(0,0,0,65),(draw[0]+45,draw[1]+50),30)
        except:
            print('probleme afficher moves possibles')

def afficheechec(plateau, listeblanc, listenoir):
    afficheroi = None
    if testcheck("blanc",plateau,listeblanc,listenoir):
        for piece in listeblanc:
            if type(piece) == Roi:
                afficheroi = "blanc"
                coord = format(piece.coord)
    elif testcheck("noir",plateau,listeblanc,listenoir):
        for piece in listenoir:
            if type(piece) == Roi:
                afficheroi = "noir"
                coord = format(piece.coord)
                
    #Affiche en rouge si echec:
    if afficheroi != None:
        pygame.draw.rect(FENETRE,(255,0,0),pygame.Rect(coord[0],coord[1],90,90))
        
def ismate(couleur, plateau, listeblanc, listenoir):
    mate = True
    if testcheck(couleur, plateau, listeblanc, listenoir):
        print(couleur)
        if couleur == "noir": listecouleur = listenoir
        else: listecouleur = listeblanc
        for piece in listecouleur:
            plateau, select, moves, listenoir, listeblanc, test = deplacement(piece.coord,plateau, None, [], listenoir, listeblanc,joueur)
            if moves != []:
                mate = False
        return mate

def promotionpossible(plateau,listeblanc,listenoir):
    for piece in listeblanc:
        if (type(piece) == Pion and piece.coord[0] == 7 and piece.couleur == "blanc") :
            return True,piece.coord,piece.couleur
    for piece in listenoir:
        if (type(piece) == Pion and piece.coord[0] == 0 and piece.couleur == "noir"):
            return True,piece.coord,piece.couleur
    return False

def affichepromote(plateau,coord,couleur):
    if couleur == "blanc":
        FENETRE.blit(promote_w,(format(coord)[0]+60,format(coord)[1]+15))
        return (format(coord)[0]+60,format(coord)[1]+15),couleur
    else:
        FENETRE.blit(promote_b,(format(coord)[0]+60,format(coord)[1]-265))
        return (format(coord)[0]+60,format(coord)[1]-265),couleur
        
    
##Creation
plateau = [[[] for i in range(8)]for j in range(8)]
listeblanc,listenoir = [],[]

#Blanc
for i in range(8):
    p = Pion([1,i],"blanc")
    listeblanc.append(p)

for i in range(2):
    t = Tour([0,i*7],"blanc")
    c = Cavalier([0,i*5+1],"blanc")
    f = Fou([0,i*3+2],"blanc")
    listeblanc+= [t,c,f] 

listeblanc.append(Dame([0,3],"blanc"))
listeblanc.append(Roi([0,4],"blanc"))

#Noir
for i in range(8):
    p = Pion([6,i],"noir")
    listenoir.append(p)

for i in range(2):
    t = Tour([7,i*7],"noir")
    c = Cavalier([7,i*5+1],"noir")
    f = Fou([7,i*3+2],"noir")
    listenoir+= [t,c,f]

listenoir.append(Dame([7,3],"noir"))
listenoir.append(Roi([7,4],"noir"))

for piece in listeblanc+listenoir:
    plateau[piece.coord[0]][piece.coord[1]] = piece

# for i in range(len(plateau)):
#     print(8-i,plateau[-1-i])

##Pygame
select = None
active = True
moves =[]
test = False
joueur = "blanc"

clock = pygame.time.Clock()
while active:
    clock.tick(30)
    # Recuperer tout les inputs
    pygame.display.flip()
    for event in pygame.event.get():
        FENETRE.blit(echiquier, (0,0))

        #Bouge une piece
        
        if event.type == pygame.MOUSEBUTTONUP and not promotionpossible(plateau,listeblanc,listenoir):
            pos = unformat(pygame.mouse.get_pos())
            print(format(pos),pos)
            
            plateau, select, moves, listenoir, listeblanc, test = deplacement(pos,plateau,select,moves,listenoir,listeblanc,joueur)
        
            if test:
                if joueur == "blanc":
                    joueur = "noir"
                else:
                    joueur = "blanc"
                print("C'est le tour de",joueur)
                test = False
            
            if ismate(joueur, plateau, listeblanc, listenoir):
                print('mate')
                active = False
                
        if select != None and select.couleur != joueur:
            select = None
            moves = []
        
        
        
        
        
        afficheechec(plateau, listeblanc, listenoir)
        affichemove(moves)
                        
        #Affiche les pieces
        for tab in plateau:
            for piece in tab:
                if type(piece) != list:
                    FENETRE.blit(piece.image,format(piece.coord))
                    
        
        
        
        #Promotion            
        if promotionpossible(plateau,listeblanc,listenoir):
            coord, couleur = affichepromote(plateau,promotionpossible(plateau,listeblanc,listenoir)[1],promotionpossible(plateau,listeblanc,listenoir)[2])
            
            coordpion = promotionpossible(plateau,listeblanc,listenoir)[1]
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                print(pos,unformat(pos))
                print("\n",coord[0],"<=",pos[0],"<",coord[0]+80)
                print(coord[1],"<=",pos[1],"<",coord[1]+80)
        
                listepiece = [Cavalier,Fou,Tour,Dame]
                for i in range(4):
                    if coord[0] <= pos[0] < coord[0]+80 and coord[1] <= pos[1]-i*80 <= coord[1]+80:
                        print(listepiece[i])
                        print(unformat(coord),coord)
                        elpion = plateau[coordpion[0]][coordpion[1]]
 
                        try:
                            listeblanc.remove(elpion)
                            evolve = listepiece[i](elpion.coord,elpion.couleur)
                            listeblanc.append(evolve)

                        except:
                            listenoir.remove(elpion)
                            evolve = listepiece[i](elpion.coord,elpion.couleur)
                            listenoir.append(evolve)
                        plateau[elpion.coord[0]][elpion.coord[1]] = evolve
                    
        
        # Pour fermer la FENETRE
        if event.type == QUIT:
            active = False
            pygame.quit()
            
sleep(5)
pygame.quit()
