from Projett import *
from interfacegraphique import *
import pygame


def choixdujeu():
    choix=input("Avec quelle interface voulez vous jouer ? (1 = console, 2 = inteface graphique) " )
    if choix=="1":
        partie()
    elif choix=="2":
        start()
    else:
        choixdujeu()

choixdujeu()