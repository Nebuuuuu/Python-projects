from random import *

class Arbre :
    def __init__(self,etiq,prof, val= None):
        self.etiq = etiq
        self.val = val
        self.listef = []
        self.grille = None
        self.main = None


        if prof > 1 :
            self.listef = [Arbre(self.etiq*10 +1+i,prof-1) for i in range(7)]


        else:
            self.listef = [None for i in range(7)]





        # print(self.listef)

    def __str__(self):
        """Un affichage d'un arbre est constitué de :
        - le nom de la racine et sa valeur
        - le nom de ses 7 fils
        """
        # On vérifie qu'on n'est pas en présence d'un arbre vide :
        if self is None:
            return None
        else:
            # Initialisation de la chaine à retourner avec étiquette et valeur de la racine du sous-arbre à afficher :
            chaine = str(self.etiq) + " ; " + str(self.val) + "    " + str(self.main) +  " || "
            # Vérification de la présence d'un fils gauche :
            for i in range(6):
                if self.listef[i] == None:
                    chaine+= "None -- "
                else:

                    chaine+= " " + str(self.listef[i].etiq) + "   -- "
            if self.listef[6] == None:
                chaine+= "None "
            else:
                chaine+= " " + str(self.listef[6].etiq)
            return chaine

##

    def tableau(self):
        """Cette fonction affiche un tableau décrivant l'arbre.
        On donne dans ce tableau, dans l'ordre, le nom du noeud puis le nom du fils gauche et enfin le nom du fils droit.
        Si un ou les fils n'existe(nt) pas, ils sont remplacés par None.
        Cette fonction est récursive.
        """
        # Si l'arbre n'est pas vide :
        if self is not None:
            # On "l'affiche" au sens de __str__
            print(self)
            # Si les enfants ne sont pas None, on les traite également :
            for i in range(7):
                if self.listef[i] is not None:
                    self.listef[i].tableau()



            return



    def ajout(self, feuille, lst_fils):
        """Cette méthode ajoute un fils à un noeud donné"""

        if self.etiq == feuille:

            for i in range(0,7-len(lst_fils)-1):

                if lst_fils[i] !=None:

                    self.listef[i]= lst_fils[i]

        else:
            for i in range(7-len(lst_fils)-1):
                if self.listef[i]!= None:
                    self.listef[i].ajout(feuille, lst_fils)



    def est_vide(self):
        """Cette méthode renvoie True si l'arbre est vide"""
        for e in self.listef:
            if e != None:
                return False

        return True

##
    def valeur(self, noeud, val):
        """Cette méthode donne la valeur du noeud pris en paramètre"""
        if self.etiq == noeud:
            self.val = val

        else:
            for i in range(7):
                if self.listef[i]!= None:
                    self.listef[i].valeur(noeud, val)

##
    def meilleure_val(self):
        """Cette méthode renvoie le fils avec la meilleure valeur afin que l'IA puisse gagner"""

        maxi = -999999
        meilleur_fils = -999999

        for i in range(7):

            if self.listef[i] != None:

                # print(self.listef[i].val, "Colonne", i+1)
                if self.listef[i].val != None:
                    if self.listef[i].val > maxi:

                        maxi = self.listef[i].val
                        meilleur_fils = [self.listef[i]]

                    elif self.listef[i].val == maxi:
                        meilleur_fils.append(self.listef[i])

        filsrdm = meilleur_fils[randint(0,len(meilleur_fils)-1)]
        self.main = filsrdm.etiq

        return filsrdm.val


    def pire_val(self):
        """Cette méthode renvoie le fils avec la pire valeur afin que l'IA sache qu'il ne faut pas jouer ca coup pour gagner"""

        min = 100000
        pire_fils = 1000000

        for i in range(7):
            if self.listef[i] != None:

                # print(self.listef[i].val, "Colonne", i+1)
                if self.listef[i].val != None:
                    if self.listef[i].val < min:

                        min = self.listef[i].val
                        pire_fils = [self.listef[i]]

                    elif self.listef[i].val == min:
                        pire_fils.append(self.listef[i])


        filsrdm = pire_fils[randint(0,len(pire_fils)-1)]
        self.main = filsrdm.etiq

        return filsrdm.val


##
    def creer_grille(self,grille):
        """Cette méthode crée une grille"""

        #Creation de la grille
        nouv_grille =[]
        for i in range(6):
            ligne =[]
            for j in range(7):
                ligne.append(grille[i][j])
            nouv_grille.append(ligne)

        self.grille = nouv_grille

##
    def barem(self,j):
        """Cette méthode renvoie un résultat négatif si le joueur est gagnat eg un résultat positif si l'IA est gagnante
        Joueur gagnant : renvoie resultat negatif
        Bot gagnant : renvoie resultat positif
        """

        somme1, somme2 = [],[]
        testj = j

        for joueur in range(2):
            liste = []
            if joueur == 1:
                if testj == 1:
                    testj=2
                else:
                    testj=1


##
            # verif colonne(fonctionnelle)
            nbjetons = 0
            maxi = 0
            for l in range(3):
                case = 0
                for c in range(7):
                    for i in range(4):
                        if l+i <6 and self.grille[l][c] == testj:
                            if (self.grille[l+i][c]==testj):
                                nbjetons = nbjetons + 1
                                case += 1
                            elif (self.grille[l+i][c]==0 and case < 3):
                                case += 1
                            else:
                                if nbjetons > maxi:
                                    maxi = nbjetons
                                nbjetons = 0
                                case = 0

                    if nbjetons > maxi:
                        maxi = nbjetons
                    nbjetons = 0
                    case = 0


            if maxi == 4:
                val = 10000
            elif maxi == 3:
                val = 100
            elif maxi == 2:
                val = 10
            else:
                val = 1
            liste.append(val)


            maxi = 0
            nbjetons = 0


            #Verif ligne (fonctionnelle)
            for l in range(6):
                case = 0
                for c in range(4):
                    for i in range(4):
                        if c+i <7 and self.grille[l][c] == testj :
                            if (self.grille[l][c+i]==testj):
                                # Un jeton identique de plus
                                nbjetons = nbjetons + 1
                                case += 1
                            elif (self.grille[l][c+i]==0 and case < 3):
                                case += 1
                            else:
                                if nbjetons > maxi:
                                    maxi = nbjetons
                                # On redémarre le comptage à 0
                                nbjetons = 0
                                case = 0

                    if nbjetons > maxi:
                        maxi = nbjetons
                    # On redémarre le comptage à 0
                    nbjetons = 0
                    case = 0



            if maxi ==4:
                val = 10000
            elif maxi == 3:
                val = 100
            elif maxi == 2:
                val = 10
            else:
                val = 1
            liste.append(val)

            maxi = 0
            nbjetons = 0


            #diag haut gauche-bas droit
            for l in range(6):
                case = 0
                for c in range(7):
                    for i in range(4):
                        if ((c+i >= 0) and (l-i < 6) and (c+i <7) and (l-i >=0)):
                            if (self.grille[l-i][c+i] == testj):
                                # Un jeton identique de plus
                                nbjetons = nbjetons + 1
                                case += 1
                            elif (self.grille[l-i][c+i] == 0 and case < 3):
                                case += 1
                            else:
                                if nbjetons > maxi:
                                    maxi = nbjetons
                                # On redémarre le comptage à 0
                                nbjetons = 0
                                case = 0

                    if nbjetons > maxi:
                        maxi = nbjetons
                    # On redémarre le comptage à 0
                    nbjetons = 0
                    case = 0

            if maxi ==4:
                val = 10000
            elif maxi == 3:
                val = 100
            elif maxi == 2:
                val = 10
            else:
                val = 1
            liste.append(val)

            nbjetons = 0
            maxi = 0


            #diag haut droit-bas gauche
            for l in range(6):
                case = 0
                for c in range(7):
                    for i in range(4):
                        if ((c-i >= 0) and (l-i < 6) and (c-i <7) and (l-i >=0)):
                            if (self.grille[l-i][c-i] == testj):
                                # Un jeton identique de plus
                                nbjetons = nbjetons + 1
                                case += 1
                            elif (self.grille[l-i][c-i] ==0 and case < 3):
                                case += 1
                            else:
                                if nbjetons > maxi:
                                    maxi = nbjetons
                                # On redémarre le comptage à 0
                                nbjetons = 0
                                case = 0

                    if nbjetons > maxi:
                        maxi = nbjetons
                    # On redémarre le comptage à 0
                    nbjetons = 0
                    case = 0

            if maxi ==4:
                val = 10000
            elif maxi == 3:
                val = 100
            elif maxi == 2:
                val = 10
            else:
                val = 1
            liste.append(val)

            nbjetons = 0
            maxi = 0
##


            if testj == 1:
                somme2 = sum(liste)
            else:
                somme1 = sum(liste)


        if somme1 == somme2:
            return 0

        elif somme2 == max(somme1,somme2):
            return -somme2


        else:
            return somme1





    def jouer(self,grille,joueur = 1):
        """Cette méthode permet à l'IA de jouer"""

        if self == None:

            return self

        self.creer_grille(grille)

        #Alterne la couleur des jetons
        if joueur == 2:
            joueur = 1
        else:
            joueur = 2


        for indice, fils in enumerate(self.listef):
            if fils != None:
                fils.creer_grille(self.grille)


                for l in range(7):
                    if l == 6:
                        self.listef[indice], fils = None, None
                        break

                    if fils.grille[l][indice] == 0:
                        fils.grille[l][indice] = joueur
                        fils.val = fils.barem(joueur)


                        break

                if fils != None:

                    fils.jouer(fils.grille,joueur)
                    if joueur == 1:
                        self.val = self.pire_val()
                    else:
                        self.val = self.meilleure_val()



    def meilleur_coup(self,grille):
        """Cette méthode renvoie la colonne dans laquelle l'IA doit jouer afin de gagner"""
        self.jouer(grille)
        print("\n" , self.val, "Le meilleur coup est en colonne", self.main,"\n")
        # self.tableau()
        print(self.main)
        return self.main





    # def parcours_suffixe(self):
    #     """Cette méthode affiche la liste des sommets parcourus dans le cadre d'un parcours infixe.
    #     """
    #
    #     for i in range(7):
    #         if self.listef[i] != None:
    #             self.fg.parcours_suffixe()
    #